package e.com.movieapp;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        VideoView videoview = (VideoView) findViewById(R.id.videoview);
        //setting the media controller
        MediaController mediaController = new MediaController(this);
        mediaController.setAnchorView(videoview);

        //set the url of the video
        Uri uri = Uri.parse("https://www.khanacademy.org/science/biology/energy-and-enzymes/the-laws-of-thermodynamics/v/the-second-law-of-thermodynamics");
        //setting the video
        videoview.setMediaController(mediaController);
        videoview.setVideoURI(uri);
        //videoview.requestfocus();
        videoview.start();
    }
}
